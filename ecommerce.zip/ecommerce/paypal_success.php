<?php session_start(); ?>
<html>
	<head>
		<title>Payment Successful</title>
	</head>
<body>
<h2>Welcome<?php echo $_SESSION['customer_email'];?></h2>
<h3>Your Payment Was Successful ! </h3>
<h3><a href="http://www.ecommerce.com/myshop/customer/my_account.php">Go to your Account</a></h3>
</body>
</html>		